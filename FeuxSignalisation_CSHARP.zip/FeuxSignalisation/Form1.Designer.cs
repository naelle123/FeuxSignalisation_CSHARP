﻿namespace FeuxSignalisation
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pbVert = new System.Windows.Forms.PictureBox();
            this.pbRouge = new System.Windows.Forms.PictureBox();
            this.pbOrange = new System.Windows.Forms.PictureBox();
            this.btnChanger = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pbVert)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRouge)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOrange)).BeginInit();
            this.SuspendLayout();
            // 
            // pbVert
            // 
            this.pbVert.BackColor = System.Drawing.Color.Black;
            this.pbVert.Image = global::FeuxSignalisation.Properties.Resources.cercle_vert;
            this.pbVert.Location = new System.Drawing.Point(206, 14);
            this.pbVert.Name = "pbVert";
            this.pbVert.Size = new System.Drawing.Size(126, 122);
            this.pbVert.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbVert.TabIndex = 0;
            this.pbVert.TabStop = false;
            this.pbVert.Click += new System.EventHandler(this.pbVert_Click);
            // 
            // pbRouge
            // 
            this.pbRouge.BackColor = System.Drawing.Color.Black;
            this.pbRouge.Image = global::FeuxSignalisation.Properties.Resources.cercle_rouge;
            this.pbRouge.Location = new System.Drawing.Point(206, 320);
            this.pbRouge.Name = "pbRouge";
            this.pbRouge.Size = new System.Drawing.Size(126, 122);
            this.pbRouge.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbRouge.TabIndex = 0;
            this.pbRouge.TabStop = false;
            // 
            // pbOrange
            // 
            this.pbOrange.BackColor = System.Drawing.Color.Black;
            this.pbOrange.Image = global::FeuxSignalisation.Properties.Resources.cercle_orange;
            this.pbOrange.Location = new System.Drawing.Point(206, 172);
            this.pbOrange.Name = "pbOrange";
            this.pbOrange.Size = new System.Drawing.Size(126, 122);
            this.pbOrange.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbOrange.TabIndex = 0;
            this.pbOrange.TabStop = false;
            this.pbOrange.Click += new System.EventHandler(this.pbOrange_Click);
            // 
            // btnChanger
            // 
            this.btnChanger.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnChanger.Font = new System.Drawing.Font("Algerian", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChanger.Location = new System.Drawing.Point(186, 461);
            this.btnChanger.Name = "btnChanger";
            this.btnChanger.Size = new System.Drawing.Size(169, 67);
            this.btnChanger.TabIndex = 1;
            this.btnChanger.Text = "changer";
            this.btnChanger.UseVisualStyleBackColor = false;
            this.btnChanger.Click += new System.EventHandler(this.btnChanger_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(501, 552);
            this.Controls.Add(this.btnChanger);
            this.Controls.Add(this.pbOrange);
            this.Controls.Add(this.pbVert);
            this.Controls.Add(this.pbRouge);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbVert)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRouge)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOrange)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pbVert;
        private System.Windows.Forms.PictureBox pbRouge;
        private System.Windows.Forms.PictureBox pbOrange;
        private System.Windows.Forms.Button btnChanger;
    }
}

