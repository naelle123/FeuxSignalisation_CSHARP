﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FeuxSignalisation
{
    public partial class Form2 : Form
    {
        private SoundPlayer player;
        private Timer timer;
        private int interval = 5000;
        public Form2()
        {
            InitializeComponent();
            player = new SoundPlayer(@"D:\c#\exo d'application\FeuxSignalisation\Resources\tl_sound.WAV");
            timer = new Timer();
            timer.Interval = interval;
            timer.Tick += timer1_Tick;
            timer.Start();

        }
        private void Plasound()
        {
            try
            {
                player.Stop();
                player.Play();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de la lecture du son : " + ex.Message);
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            pbVert.Visible = true;
            pbRouge.Visible = false;
            pbOrange.Visible = false;
            pbRouge.SizeMode = PictureBoxSizeMode.Zoom;
            pbOrange.SizeMode = PictureBoxSizeMode.Zoom;
            pbVert.SizeMode = PictureBoxSizeMode.Zoom;
            Plasound();

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (pbRouge.Visible)
            {
                pbVert.Visible = false;
                pbRouge.Visible = false;
                pbOrange.Visible = true;
                Plasound();
            }
            else if (pbOrange.Visible)
            {
                pbVert.Visible = true;
                pbRouge.Visible = false;
                pbOrange.Visible = false;
                Plasound();
            }
            else
            {
                pbVert.Visible = false;
                pbRouge.Visible = true;
                pbOrange.Visible = false;
                Plasound();
            }
        }
    }
}
