﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FeuxSignalisation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void pbVert_Click(object sender, EventArgs e)
        {
        }

        private void btnChanger_Click(object sender, EventArgs e)
        {
            if(pbRouge.Visible)
            {
                pbVert.Visible = false;
                pbRouge.Visible = false;
                pbOrange.Visible = true;
            }
            else if (pbOrange.Visible)
            {
                pbVert.Visible = true;
                pbRouge.Visible = false;
                pbOrange.Visible = false;
            }
            else
            {
                pbVert.Visible = false;
                pbRouge.Visible = true;
                pbOrange.Visible = false;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pbVert.Visible = true;
            pbRouge.Visible = false;
            pbOrange.Visible = false;
            pbRouge.SizeMode = PictureBoxSizeMode.Zoom;
            pbOrange.SizeMode = PictureBoxSizeMode.Zoom;
            pbVert.SizeMode = PictureBoxSizeMode.Zoom;

        }

        private void pbOrange_Click(object sender, EventArgs e)
        {

        }
    }
}
